import React, { Component } from "react";
import Child from "Components/Child";
import "./parent.scss";

class Parent extends Component {
  constructor() {
    super();
    this.state = { childTalked: "과연 자식은 무슨 말을 할까..?" };
  }

  onUpdateChild = (childTalked) => {
    this.setState({ childTalked });
  };

  render() {
    const { childTalked } = this.state;
    console.log(childTalked, "부모 상태");

    return (
      <div className="parent-container">
        <div className="parent-left">
          <span className="parent-title">NaNBuMo</span>
        </div>
        <div className="parent-right">
          <div>
            <span>자식아 어디 한번 말해보렴</span>
            <img
              src="https://image.flaticon.com/icons/svg/2044/2044642.svg"
              alt="ear"
            ></img>
          </div>
          <div className="parent-inner">
            <Child fromChild={this.onUpdateChild} />
            <span className="bold">{childTalked}</span>
          </div>
        </div>
      </div>
    );
  }
}

export default Parent;
