export { default } from "./Parent";
