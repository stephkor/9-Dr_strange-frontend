import React, { Component } from "react";
import "./child.scss";

class Child extends Component {
  constructor() {
    super();
    this.state = { childTalked: "" };
  }
  toParent = e => {
    const { childTalked } = this.state;
    if (e.key === "Enter") {
      this.setState({ childTalked: e.target.value });
      this.props.fromChild(childTalked);
    }
  };
  render() {
    console.log(this.props);
    console.log(this.state.childTalked, "자식상태쓰");
    return (
      <div className="child-container">
        <b>NanJaSik</b>
        <p>제가 전달하고 싶은 말은요..</p>
        <input className="child-input" onKeyDown={this.toParent}></input>
      </div>
    );
  }
}

export default Child;
