// import React from "react";
// import Parent from "Components/Parent";
// import Child from "Components/Child";

// const Main = () => {
//   <Parent />;
// };

// export default Main;
